<?php
namespace Opencart\Admin\Controller\Extension\NovakurDark\Theme;

class NovakurDark extends \Opencart\System\Engine\Controller {

    public function index(): void {
        $this->load->language('extension/novakur_dark/theme/novakur_dark');
        $this->document->setTitle($this->language->get('heading_title'));

        $data['breadcrumbs'] = [
            ['text' => $this->language->get('text_home'),      'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])],
            ['text' => $this->language->get('text_extension'),  'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=theme')],
            ['text' => $this->language->get('heading_title'),   'href' => $this->url->link('extension/novakur_dark/theme/novakur_dark', 'user_token=' . $this->session->data['user_token'])],
        ];

        $data['save']   = $this->url->link('extension/novakur_dark/theme/novakur_dark.save',   'user_token=' . $this->session->data['user_token']);
        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=theme');

        $data['theme_novakur_dark_primary_color']   = $this->config->get('theme_novakur_dark_primary_color')   ?: '#f59e0b';
        $data['theme_novakur_dark_container_width'] = $this->config->get('theme_novakur_dark_container_width') ?: 1280;
        $data['theme_novakur_dark_status']          = $this->config->get('theme_novakur_dark_status');

        $data['header']      = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer']      = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/novakur_dark/theme/novakur_dark', $data));
    }

    public function save(): void {
        $this->load->language('extension/novakur_dark/theme/novakur_dark');
        $json = [];
        if (!$this->user->hasPermission('modify', 'extension/novakur_dark/theme/novakur_dark')) {
            $json['error'] = 'No permission';
        }
        if (!$json) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting('theme_novakur_dark', $this->request->post);
            $json['success'] = $this->language->get('text_success');
        }
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('setting/event');
        $this->model_setting_event->addEvent([
            'code'        => 'novakur_dark',
            'description' => 'NovaKur Dark theme template override',
            'trigger'     => 'catalog/view/*/before',
            'action'      => 'extension/novakur_dark/event/novakur_dark.view',
            'status'      => 1,
            'sort_order'  => 2,
        ]);
    }

    public function uninstall(): void {
        $this->load->model('setting/event');
        $this->model_setting_event->deleteEventByCode('novakur_dark');
    }
}
