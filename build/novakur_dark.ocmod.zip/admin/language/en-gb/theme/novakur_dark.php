<?php
$_['heading_title']    = 'NovaKur Dark Theme';
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified NovaKur Dark theme settings!';
$_['text_edit']        = 'Edit NovaKur Dark';
$_['entry_primary_color']   = 'Accent Color';
$_['entry_container_width'] = 'Container Width (px)';
$_['button_save']   = 'Save';
$_['button_cancel'] = 'Cancel';
